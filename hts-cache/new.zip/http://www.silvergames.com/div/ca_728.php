<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body style="padding:0;margin:0;">
        <SCRIPT language="Javascript">
            var cpmstar_rnd=Math.round(Math.random()*999999);
            var cpmstar_pid=13916;
            document.writeln("<SCR"+"IPT language='Javascript' src='http://server.cpmstar.com/view.aspx?poolid="+cpmstar_pid+"&script=1&rnd="+cpmstar_rnd+"'></SCR"+"IPT>");
        </SCRIPT>
    </body>
</html>
