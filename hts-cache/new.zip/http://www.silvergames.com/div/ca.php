<!DOCTYPE html>
<html>
    <head>
        <title>The CPMStar Loader</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <script src="http://server.cpmstar.com/view.aspx?poolid=21836&multi=3&script=1"></script>
        <script src="http://server.cpmstar.com/cached/textad.js"></script>
    </head>
    <body>
        <script type='text/javascript'>
            parent.$(window).load(function () {
                setTimeout(function () {
                    parent.$('#dynamic-editorial').html('<ul><li><a href="' + cpmStar.getLink() + '" target="_blank" rel="nofollow"><img src="' + cpmStar.getImageUrl(220, 140) + '" width="90" height="57"/></a></li><li><a href="' + cpmStar.getLink() + '" target="_blank" rel="nofollow">' + cpmStar.getTitle() + '</a></li></ul>');
                    cpmStar.nextAd();
                }, 0);
                setTimeout(function () {
                    parent.$('#dynamic-editorial-2').html('<ul><li><a href="' + cpmStar.getLink() + '" target="_blank" rel="nofollow"><img src="' + cpmStar.getImageUrl(220, 140) + '" width="90" height="57"/></a></li><li><a href="' + cpmStar.getLink() + '" target="_blank" rel="nofollow">' + cpmStar.getTitle() + '</a></li></ul>');
                    cpmStar.nextAd();
                }, 300);
                setTimeout(function () {
                    parent.$('#dynamic-editorial-3').html('<ul><li><a href="' + cpmStar.getLink() + '" target="_blank" rel="nofollow"><img src="' + cpmStar.getImageUrl(220, 140) + '" width="90" height="57"/></a></li><li><a href="' + cpmStar.getLink() + '" target="_blank" rel="nofollow">' + cpmStar.getTitle() + '</a></li></ul>');
                }, 600);
                setTimeout(function () {
                    parent.$('#dynamic-editorial-2').slideUp(function() {
                       parent.$('#dynamic-editorial-2').insertBefore(parent.$("#dynamic-editorial")).slideDown();
                    });
                }, 60000);
                
        });
        </script>
    </body>
</html>
