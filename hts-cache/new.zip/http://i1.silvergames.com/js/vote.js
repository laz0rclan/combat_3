function vote(v, g){
    $.get('/div/vote.php?v='+ v + '&g=' + g, function(data) {
        $('#voted').html(data);
    });
    setTimeout( function() {$('#voted').fadeOut("slow");}, 1200 );
    $('#voted').html("");
    $('#voted').fadeIn();
}
